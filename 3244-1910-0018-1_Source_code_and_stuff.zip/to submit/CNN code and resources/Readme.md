The pre-trained word vectors can be downloaded from https://fasttext.cc/docs/en/crawl-vectors.html
Download the english ones
