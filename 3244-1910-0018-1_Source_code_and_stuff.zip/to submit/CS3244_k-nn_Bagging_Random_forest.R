#########original dataset
#reading the data
data<-read.csv(file.choose(),header=T)
names(data)
data<-data[,-c(1:8,10,12,14,16,18,20,22,24,32,35,36,37)]
data[,14]<-as.factor(data$starts_with_5W1H_content)
data[,15]<-as.factor(data$starts_with_5W1H_title)
data[,12]<-as.factor(data$starts_with_number_content)
data[,11]<-as.factor(data$starts_with_number_title)
data[,18]<-as.factor(data$label)
dim(data)

#separating into test and training
set.seed(1)
dim(data)
n <- dim(data)[1]
train <- sample(1:n, 0.8*n)
train <- sort(train)
test <- setdiff(1:n, train)
datatrain<-data[train,]
datatrain$label<-as.factor(datatrain$label)
datatest<-data[test,]
datatest$label<-as.factor(datatest$label)
ans<-as.factor(datatest$label)
dim(data)
dim(datatest)
dim(datatrain)

names(data)
scaledatatrain<-scale(datatrain[,-c(11,12,14,15,18)])
scaledatatrain<-cbind(scaledatatrain,datatrain[,c(11,12,14,15,18)])
scaledatatrain<-as.data.frame(scaledatatrain)

scaledatatest<-scale(datatest[,-c(11,12,14,15,18)])
scaledatatest<-cbind(scaledatatest,datatest[,c(11,12,14,15,18)])
scaledatatest<-as.data.frame(scaledatatest)
names(scaledatatest)

#BAGGING
library(randomForest)
num<-seq(100,1500,100)
msebag<-rep(0,15)
for (i in 1:15){
  bag<-randomForest(label~., data=datatrain, mtry=17,importance=T,ntree=num[i])
  pred1<-predict(bag,datatest)
  msebag[i] = mean(pred1!=ans)
} 
msebag
which.min(msebag)
1-msebag[which.min(msebag)] 

#bagging final model:
bag<-randomForest(label~.,data=data,mtry=17,importance=T,ntree=600)
pred1<-predict(bag,datatest)
table(pred1,ans,dnn=c("predicted","true_label"))
plot(1-msebag,ylab="prediction accuracy",main="Prediction accuracy of bagging with different number of trees",pch=19,xlab="number of trees (x10^2)",type="l")
abline(v=6,lty=2,col="red")
varImpPlot(bag)

#random forest
library(randomForest)
numm<-seq(1,16,1)
mserf<-rep(0,16)
for (i in numm){
  rf<-randomForest(label~.,data=datatrain,mtry=i,importance=T,ntree=1000)
  pred2<-predict(rf,datatest)
  mserf[i]<-mean(pred2!=ans)
}
mserf
which.min(mserf)
plot(1-mserf,pch=19,ylab="prediction accuracy",main="Prediction accuracy for different number of m",xlab="number of m<p considered")
abline(v=4,lty=2,col="red")

mserffor4<-rep(0,15)
for( i in 1:15){
  rf<-randomForest(label~.,data=datatrain,mtry=4,importance=T,ntree=num[i])
  pred2<-predict(rf,datatest)
  mserffor4[i]<-mean(pred2!=ans)
}
plot(1-mserffor4,main="Prediction accuracy for different number of trees for m=4",ylab="prediction accuracy",xlab="number of trees (x10^2)",pch=19)
abline(v=14,lty=2,col="red")
which.min(mserffor4)
1-mserffor4[14]#prediction accuracy

#final: mtry=4,1400 trees
rf<-randomForest(label~.,data=data,mtry=4,importance=T,ntree=1400)
varImpPlot(rf)
pred2<-predict(rf,datatest)
table(pred2,ans,dnn=c("predicted","true_label"))

#knn
library(class)
mseknn<-rep(0,500)
names(scaledata)
dim(scaledata)
for (i in 1:500){ #too many ties for k=500
  knnpred<-knn(scaledata[,-18],scaledatatest[,-18],cl=scaledata[,18],k=i)
  mseknn[i]<-mean(knnpred!=ans)
}
plot(1-mseknn[1:499],type="l",ylab="prediction accuracy",xlab="number of neighbours k",main="Prediction accuracy for different number of k")
which.min(mseknn[1:499])
1-mseknn[which.min(mseknn[1:499])]
abline(v=11,lty=2,col="red")

#final model for knn
knnpred<-knn(scaledata[,-18],scaledatatest[,-18],cl=scaledata[,18],k=11)
mean(knnpred!=ans)

#to predict for 2 points, microscopic analysis
topredict<-read.csv(file.choose(),header=T)
topredictf<-topredict[c(1,3),]
topredictf<-topredictf[,-c(1:8,10,12,14,16,18,20,22,24,32,35,36,37)]
topredictf<-rbind(datatrain,topredictf)
dim(topredictf)
topredictf<-topredictf[c(15631,15632),]
topredictf
predict(bag,topredictf)
predict(rf,topredictf)

#scaling to predict
library(class)
topredictf
scaletopredict<-scale(topredictf[,-c(11,12,14,15,18)])
scaletopredict<-cbind(topredictf,topredictf[,c(11,12,14,15,18)])
scaletopredict<-as.data.frame(scaletopredict)

knntopredict<-knn(scaledatatrain[,-18],topredictf[,-18],cl=scaledatatrain[,18],k=11)
knntopredict

##############undersampled
data<-read.csv(file.choose(),header=T)
names(data)
data<-data[,-c(1:8,10,12,14,16,18,20,22,24,32,35,36,37)]
data[,14]<-as.factor(data$starts_with_5W1H_content)
data[,15]<-as.factor(data$starts_with_5W1H_title)
data[,12]<-as.factor(data$starts_with_number_content)
data[,11]<-as.factor(data$starts_with_number_title)
data[,18]<-as.factor(data$label)
dim(data)

#separating into test and training
set.seed(1)
n <- dim(data)[1]
train <- sample(1:n, 0.8*n)
train <- sort(train)
test <- setdiff(1:n, train)
datatrain<-data[train,]
datatrain$label<-as.factor(datatrain$label)
datatest<-data[test,]
datatest$label<-as.factor(datatest$label)
ans<-as.factor(datatest$label)
dim(data)
dim(datatest)
dim(datatrain)

#under sampling
library(ROSE)
datatrainunder<-ovun.sample(label~.,data=datatrain,method="under")
table(datatrainunder$data$label)
datatrainunder1<-datatrainunder$data
datatrainunder1<-as.data.frame(datatrainunder1)

datatestunder<-ovun.sample(label~.,data=datatest,method="under")
datatestunder1<-datatestunder$data
datatestunder1<-as.data.frame(datatestunder1)
anstest<-as.factor(datatestunder1[,18])


#scaling data
names(datatrainunder1)
scaledatatrain<-scale(datatrainunder1[,-c(11,12,14,15,18)])
scaledatatrain<-cbind(scaledatatrain,datatrainunder1[,c(11,12,14,15,18)])
scaledatatrain<-as.data.frame(scaledatatrain)

scaledatatest<-scale(datatestunder1[,-c(11,12,14,15,18)])
scaledatatest<-cbind(scaledatatest,datatestunder1[,c(11,12,14,15,18)])
scaledatatest<-as.data.frame(scaledatatest)

#BAGGING
library(randomForest)
names(data)
num<-seq(100,1500,100) #number of trees
msebag<-rep(0,15)
msebag
for (i in 1:15){
  bag<-randomForest(label~., data=datatrainunder1, mtry=17,importance=T,ntree=num[i])
  pred1<-predict(bag,datatestunder1)
  msebag[i] = mean(pred1!=anstest)
} 
msebag
which.min(msebag)
1-msebag[which.min(msebag)] 
plot(1-msebag,ylab="prediction accuracy",main="Prediction accuracy of bagging with different number of trees",pch=19,xlab="number of trees (x10^2)",type="l")
abline(v=3,lty=2,col="red")

#bagging final model:
bag<-randomForest(label~.,data=datatrainunder1,mtry=17,importance=T,ntree=300)
pred1<-predict(bag,datatestunder1)
table(pred1,anstest,dnn=c("predicted","true_label"))
mean(pred1==anstest)

#random forest
numm<-seq(1,16,1)
mserf<-rep(0,16)
for (i in 1:16){
  rf<-randomForest(label~.,data=datatrainunder1,mtry=i,importance=T,ntree=500)
  pred2<-predict(rf,datatestunder1)
  mserf[i]<-mean(pred2!=anstest)
}
mserf
which.min(mserf)
plot(1-mserf,pch=19,ylab="prediction accuracy",main="Prediction accuracy for different number of m",xlab="number of m<p considered")
abline(v=4,lty=2,col="red")

mserffor4<-rep(0,15)
mserffor4
for( i in 10:15){
  rf<-randomForest(label~.,data=datatrainunder1,mtry=4,importance=T,ntree=num[i])
  pred2<-predict(rf,datatestunder1)
  mserffor4[i]<-mean(pred2!=anstest)
}
mserffor4
plot(1-mserffor4,main="Prediction accuracy for different number of trees for m=1",ylab="prediction accuracy",xlab="number of trees (x10^2)",pch=19,type="l")
which.min(mserffor4)
1-mserffor4[7]#prediction accuracy

#final: mtry=1,1100 trees
rf<-randomForest(label~.,data=datatrainunder1,mtry=4,importance=T,ntree=700)
varImpPlot(rf)
pred2<-predict(rf,datatestunder1)
1-mean(pred2!=anstest)
table(pred2,anstest,dnn=c("predicted","true_label"))
importance(rf,2)# mean decrease in gini

rf
#knn
library(class)
mseknn<-rep(0,500) 
for (i in 1:500){
  knnpred<-knn(scaledatatrain[,-18],scaledatatest[,-18],cl=scaledatatrain[,18],k=i)
  mseknn[i]<-mean(knnpred!=anstest)
}
plot(1-mseknn[1:499],type="l",ylab="prediction accuracy",xlab="number of neighbours k",main="Prediction accuracy for different number of k")
mseknn
which.min(mseknn[1:499])
1-mseknn[45]

#final model for knn
knnpred<-knn(scaledatatrain[,-18],scaledatatest[,-18],cl=scaledatatrain[,18],k=45)
1-mean(knnpred!=anstest)
knnpred
table(knnpred,anstest,dnn=c("predicted","true_label"))


#to predict
topredict<-read.csv(file.choose(),header=T)
topredictf<-topredict[c(1,3),]
topredictf<-topredictf[,-c(1:8,10,12,14,16,18,20,22,24,32,35,36,37)]
topredictf<-rbind(datatrainunder1,topredictf)
dim(topredictf)
topredictf<-topredictf[c(7467,7468),]
topredictf
predict(bag,topredictf)
predict(rf,topredictf)

#scaling to predict
library(class)
topredictf
scaletopredict<-scale(topredictf[,-c(11,12,14,15,18)])
scaletopredict<-cbind(topredictf,topredictf[,c(11,12,14,15,18)])
scaletopredict<-as.data.frame(scaletopredict)

knntopredict<-knn(scaledatatrain[,-18],topredictf[,-18],cl=scaledatatrain[,18],k=45)
knntopredict

###oversampled
rm(list=ls())
#with undersampling
data<-read.csv(file.choose(),header=T) #ran on extractedfeatureslarge
names(data)
data<-data[,-c(1:8,10,12,14,16,18,20,22,24,32,35,36,37)]
data<-data[,-c(2,4,6,8,9,12,13,14,16)]
names(data)
data[,6]<-as.factor(data$starts_with_number_title)
data[,7]<-as.factor(data$starts_with_5W1H_title)
data[,9]<-as.factor(data$label)
sapply(data,class)

#separating into test and training
set.seed(1)
n <- dim(data)[1]
train <- sample(1:n, 0.8*n)
train <- sort(train)
test <- setdiff(1:n, train)
datatrain<-data[train,]
datatrain$label<-as.factor(datatrain$label)
datatest<-data[test,]
datatest$label<-as.factor(datatest$label)
dim(data)
dim(datatest)
dim(datatrain)

#under sampling
library(ROSE)
datatrainover<-ovun.sample(label~.,data=datatrain,method="under")
table(datatrainover$data$label)
datatrainover1<-datatrainover$data
datatrainover1<-as.data.frame(datatrainover1)

datatestover<-ovun.sample(label~.,data=datatest,method="under")
datatestover1<-datatestover$data
datatestover1<-as.data.frame(datatestover1)
anstest<-as.factor(datatestover1[,9])


#scaling data
names(datatrainover1)
scaledatatrain<-scale(datatrainover1[,-c(6,7,9)])
scaledatatrain<-cbind(scaledatatrain,datatrainover1[,c(6,7,9)])
scaledatatrain<-as.data.frame(scaledatatrain)

scaledatatest<-scale(datatestover1[,-c(6,7,9)])
scaledatatest<-cbind(scaledatatest,datatestover1[,c(6,7,9)])
scaledatatest<-as.data.frame(scaledatatest)

#BAGGING
library(randomForest)
names(data)
num<-seq(100,1500,100) #number of trees
msebag<-rep(0,15)
msebag
for (i in 1:15){
  bag<-randomForest(label~., data=datatrainover1, mtry=8,importance=T,ntree=num[i])
  pred1<-predict(bag,datatestover1)
  msebag[i] = mean(pred1!=anstest)
} 
msebag
which.min(msebag)#growing 1100 trees best accuracy
1-msebag[which.min(msebag)] #56.160%
plot(1-msebag,ylab="prediction accuracy",main="Prediction accuracy of bagging with different number of trees",pch=19,xlab="number of trees (x10^2)",type="l")
abline(v=1,lty=2,col="red")

#bagging final model:
bag<-randomForest(label~.,data=datatrainover1,mtry=8,importance=T,ntree=1100)
pred1<-predict(bag,datatestover1)
table(pred1,anstest,dnn=c("predicted","true_label"))
bag

#random forest
numm<-seq(1,7,1)
mserf<-rep(0,7)
mserf
for (i in 1:7){
  rf<-randomForest(label~.,data=datatrainover1,mtry=i,importance=T,ntree=500)
  pred2<-predict(rf,datatestover1)
  mserf[i]<-mean(pred2!=anstest)
}
mserf
which.min(mserf)
plot(1-mserf,pch=19,ylab="prediction accuracy",main="Prediction accuracy for different number of m",xlab="number of m<p considered")
abline(v=2,lty=2,col="red")

mserffor2<-rep(0,15)
mserffor2
for( i in 1:15){
  rf<-randomForest(label~.,data=datatrainover1,mtry=2,importance=T,ntree=num[i])
  pred2<-predict(rf,datatestover1)
  mserffor2[i]<-mean(pred2!=anstest)
}
mserffor2
plot(1-mserffor2,main="Prediction accuracy for different number of trees for m=1",ylab="prediction accuracy",xlab="number of trees (x10^2)",pch=19,type="l")
which.min(mserffor2)
1-mserffor2[2]#prediction accuracy

#final: mtry=2,800 trees
rf<-randomForest(label~.,data=datatrainover1,mtry=2,importance=T,ntree=200)
pred2<-predict(rf,datatestover1)
1-mean(pred2!=anstest)
table(pred2,anstest,dnn=c("predicted","true_label"))


#knn
library(class)
names(scaledatatrain)
mseknn<-rep(0,500)
for (i in 1:500){
  knnpred<-knn(scaledatatrain[,-9],scaledatatest[,-9],cl=scaledatatrain[,9],k=i)
  mseknn[i]<-mean(knnpred!=anstest)
}
mseknn
plot(1-mseknn[1:299],type="l",ylab="prediction accuracy",xlab="number of neighbours k",main="Prediction accuracy for different number of k")
mseknn
which.min(mseknn[1:299])
1-mseknn[70]

#final model for knn
knnpred<-knn(scaledatatrain[,-9],scaledatatest[,-9],cl=scaledatatrain[,9],k=70)
1-mean(knnpred!=anstest)
table(knnpred,anstest,dnn=c("predicted","true_label"))


##########with title only
rm(list=ls())
#with undersampling
data<-read.csv(file.choose(),header=T) #ran on extractedfeatureslarge
names(data)
data<-data[,-c(1:8,10,12,14,16,18,20,22,24,32,35,36,37)]
data<-data[,-c(2,4,6,8,9,12,13,14,16)]
names(data)
data[,6]<-as.factor(data$starts_with_number_title)
data[,7]<-as.factor(data$starts_with_5W1H_title)
data[,9]<-as.factor(data$label)
sapply(data,class)

#separating into test and training
set.seed(1)
n <- dim(data)[1]
train <- sample(1:n, 0.8*n)
train <- sort(train)
test <- setdiff(1:n, train)
datatrain<-data[train,]
datatrain$label<-as.factor(datatrain$label)
datatest<-data[test,]
datatest$label<-as.factor(datatest$label)
dim(data)
dim(datatest)
dim(datatrain)

#under sampling
library(ROSE)
datatrainover<-ovun.sample(label~.,data=datatrain,method="under")
table(datatrainover$data$label)
datatrainover1<-datatrainover$data
datatrainover1<-as.data.frame(datatrainover1)

datatestover<-ovun.sample(label~.,data=datatest,method="under")
datatestover1<-datatestover$data
datatestover1<-as.data.frame(datatestover1)
anstest<-as.factor(datatestover1[,9])


#scaling data
names(datatrainover1)
scaledatatrain<-scale(datatrainover1[,-c(6,7,9)])
scaledatatrain<-cbind(scaledatatrain,datatrainover1[,c(6,7,9)])
scaledatatrain<-as.data.frame(scaledatatrain)

scaledatatest<-scale(datatestover1[,-c(6,7,9)])
scaledatatest<-cbind(scaledatatest,datatestover1[,c(6,7,9)])
scaledatatest<-as.data.frame(scaledatatest)

#BAGGING
library(randomForest)
names(data)
num<-seq(100,1500,100) #number of trees
msebag<-rep(0,15)
msebag
for (i in 1:15){
  bag<-randomForest(label~., data=datatrainover1, mtry=8,importance=T,ntree=num[i])
  pred1<-predict(bag,datatestover1)
  msebag[i] = mean(pred1!=anstest)
} 
msebag
which.min(msebag)#growing 1100 trees best accuracy
1-msebag[which.min(msebag)] #56.160%
plot(1-msebag,ylab="prediction accuracy",main="Prediction accuracy of bagging with different number of trees",pch=19,xlab="number of trees (x10^2)",type="l")
abline(v=1,lty=2,col="red")

#bagging final model:
bag<-randomForest(label~.,data=datatrainover1,mtry=8,importance=T,ntree=1100)
pred1<-predict(bag,datatestover1)
table(pred1,anstest,dnn=c("predicted","true_label"))
bag

#random forest
numm<-seq(1,7,1)
mserf<-rep(0,7)
mserf
for (i in 1:7){
  rf<-randomForest(label~.,data=datatrainover1,mtry=i,importance=T,ntree=500)
  pred2<-predict(rf,datatestover1)
  mserf[i]<-mean(pred2!=anstest)
}
mserf
which.min(mserf)
plot(1-mserf,pch=19,ylab="prediction accuracy",main="Prediction accuracy for different number of m",xlab="number of m<p considered")
abline(v=2,lty=2,col="red")

mserffor2<-rep(0,15)
mserffor2
for( i in 1:15){
  rf<-randomForest(label~.,data=datatrainover1,mtry=2,importance=T,ntree=num[i])
  pred2<-predict(rf,datatestover1)
  mserffor2[i]<-mean(pred2!=anstest)
}
mserffor2
plot(1-mserffor2,main="Prediction accuracy for different number of trees for m=1",ylab="prediction accuracy",xlab="number of trees (x10^2)",pch=19,type="l")
which.min(mserffor2)
1-mserffor2[2]#prediction accuracy

#final: mtry=2,800 trees
rf<-randomForest(label~.,data=datatrainover1,mtry=2,importance=T,ntree=200)
pred2<-predict(rf,datatestover1)
1-mean(pred2!=anstest)
table(pred2,anstest,dnn=c("predicted","true_label"))


#knn
library(class)
names(scaledatatrain)
mseknn<-rep(0,500)
for (i in 1:500){
  knnpred<-knn(scaledatatrain[,-9],scaledatatest[,-9],cl=scaledatatrain[,9],k=i)
  mseknn[i]<-mean(knnpred!=anstest)
}
mseknn
plot(1-mseknn,type="l",ylab="prediction accuracy",xlab="number of neighbours k",main="Prediction accuracy for different number of k")
mseknn
which.min(mseknn)
1-mseknn[70]

#final model for knn
knnpred<-knn(scaledatatrain[,-9],scaledatatest[,-9],cl=scaledatatrain[,9],k=70)
1-mean(knnpred!=anstest)
table(knnpred,anstest,dnn=c("predicted","true_label"))







